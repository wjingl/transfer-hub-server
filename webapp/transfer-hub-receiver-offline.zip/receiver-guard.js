/* Transfer Hub 接收端专用构建：仅接收（本文件为分发包装层，非内核） */
(function () {
  'use strict';
  function isReceive() {
    var h = (window.location.hash || '').replace(/^#/, '').toLowerCase();
    return h === 'receive' || h === 'receiver';
  }
  function enforce() {
    if (!isReceive()) {
      // replace 不产生历史记录，避免后退绕回发送页
      window.location.replace(window.location.pathname + window.location.search + '#receive');
    }
    hideSendTab();
  }
  function hideSendTab() {
    var tabs = document.querySelectorAll('button[role="tab"]');
    for (var i = 0; i < tabs.length; i++) {
      if (tabs[i].textContent.indexOf('发送') !== -1) {
        tabs[i].style.display = 'none';
      }
    }
  }
  window.addEventListener('hashchange', enforce);
  setInterval(enforce, 600);
  document.addEventListener('DOMContentLoaded', enforce);
  enforce();
})();